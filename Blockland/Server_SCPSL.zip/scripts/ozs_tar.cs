datablock particleData(ozsTarParticle)
{
    dragCoefficient      = 1;
    gravityCoefficient   = 0.15;
    inheritedVelFactor   = 0.0;
    constantAcceleration = 0.1;
    spinRandomMin = -5;
    spinRandomMax = 5;
    lifetimeMS           = 5000;
    lifetimeVarianceMS   = 200;
    textureName          = "base/data/particles/cloud";
    useInvAlpha			= 1;
    colors[0]     = "0.15 0.15 0.15 0.5";
    colors[1]     = "0.0 0.0 0.0 1.0";
    colors[2]     = "0.0 0.0 0.0 0.0";
    sizes[0]      = 4.15;
    sizes[1]      = 5.0;
    sizes[2]		= 8.0;
    times[0]		= 0.0;
    times[1]		= 0.8;
    times[2]		= 1.0;
};

datablock ParticleEmitterData(ozsTarEmitter)
{
    ejectionPeriodMS = 2;
    periodVarianceMS = 0;
    ejectionVelocity = 1;
    velocityVariance = 1.0;
    ejectionOffset   = 1.0;
    thetaMin         = 0;
    thetaMax         = 180;
    phiReferenceVel  = 0;
    phiVariance      = 360;
    overrideAdvance = false;
    particles = "ozsTarParticle";

    uiName = "SCP-106 Tar";
};

datablock ExplosionData(ozsTarExplosion)
{
   //explosionShape = "";
	soundProfile = "";

   lifeTimeMS = 100;

   emitter[0] = ozsTarEmitter;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = true;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 5.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 0;
   lightStartColor = "0 0 0";
   lightEndColor = "0 0 0";
};

datablock ProjectileData(ozsTarProjectile)
{
   projectileShapeName = "base/data/shapes/empty.dts";
   directDamage        = 0;
   directDamageType    = $DamageType::ArrowDirect;
   radiusDamageType    = $DamageType::ArrowDirect;

   brickExplosionRadius = 0;
   brickExplosionImpact = false;          //destroy a brick if we hit it directly?
   brickExplosionForce  = 10;
   brickExplosionMaxVolume = 1;          //max volume of bricks that we can destroy
   brickExplosionMaxVolumeFloating = 2;  //max volume of bricks that we can destroy if they aren't connected to the ground

   impactImpulse	     = 0;
   verticalImpulse	  = 0;
   explosion           = "ozsTarExplosion";
   particleEmitter     = "";
   explodeOnDeath		= true;

   muzzleVelocity      = 0;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 0;
   fadeDelay           = 0;
   minStickVelocity    = 0;
   bounceElasticity    = 0.2;
   bounceFriction      = 0.01;   
   bounceFriction      = 0.01;   
   bounceAngle			= 170;
   isBallistic         = false;
   gravityMod = 1.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";

   uiName = "SCP-106 Tar Explosion";
};