//
// Supporting functions.
//

function OFN_getKidnapQuip()
{
    return nameToID("OFN_Kidnap" @ getRandom(1, 2));
}

function GameConnection::OFN_Infect(%client)
{
    %player = %client.player;
    %player.setDamageLevel(0);
    %client.setLives(0);
    %client.addDeaths(1);
    %client.isOFNZombie = 1;
    %client.old_team = %client.slyrTeam;

    %new_team = getMinigameFromObject(%client).Teams.getTeamFromName($SCPSL::OFN_Team);
    %new_team.addMember(%client, "Infected", 1, 0); 
    SCPSL_forceEquipTeamItems(%player, %new_team);

    //If tumble is enabled, the player will raise their arms after recovering from it. If not, it needs to happen now.
    if($SCPSL::InfectTumble)
    {
        tumble(%player, 5);
    }
    else
    {
        %player.playthread(0,"ArmReadyBoth"); //Raise arms.
    }
    %client.OFN_ZombifyAppearance(%client.old_team);
    %client.centerPrint("<color:ffffff>\nYou've been infected by SCP-049!", 5);
}
function GameConnection::OFN_ZombifyAppearance(%this, %old_team) //Change their appearance to a zombie and raise their arms.
{
    //Big swath of code copied from Slayer's "GameConnection::applyUniform", modified to change decals, hide visors and change skin color
    //to make the player look like a zombie.
    %player = %this.player;
    %team = %old_team;

    %this.applyingUniform = true;
    %color = %team.colorRGB;
	%player.setShapeNameColor(%color);

    %zombie_skinColor = "0.626 0.71 0.453 1";
    %zombie_decalName = "HCZombie";
    %zombie_faceName = "asciiTerror";

    for(%i = 0; %i < Slayer.TeamPrefs.getCount(); %i ++)
    {
        %p = Slayer.TeamPrefs.getObject(%i);
        if(%p.category !$= "Uniform")
            continue;

        %val = %team.uni_[%p.title];
        if(%val $= "TEAMCOLOR")
            %val = %color;

        %uni_[%p.title] = %val;
    }

    %this.applyBodyColors();
    hideAllNodes(%player);

    //head
    %player.unHideNode(headSkin);
    %player.setNodeColor(headSkin, %zombie_skinColor);

    //chest
    switch(%uni_chest)
    {
        case 0:
            %player.unHideNode(chest);
            %player.setNodeColor(chest, %uni_torsoColor);
        case 1:
            %player.unHideNode(femChest);
            %player.setNodeColor(femChest, %uni_torsoColor);
    }

    //arms
    switch(%uni_lArm)
    {
        case 0:
            %player.unHideNode(lArm);
            %player.setNodeColor(lArm, %uni_lArmColor);
        case 1:
            %player.unHideNode(lArmSlim);
            %player.setNodeColor(lArmSlim, %uni_lArmColor);
    }
    switch(%uni_rArm)
    {
        case 0:
            %player.unHideNode(rArm);
            %player.setNodeColor(rArm, %uni_rArmColor);
        case 1:
            %player.unHideNode(rArmSlim);
            %player.setNodeColor(rArmSlim, %uni_rArmColor);
    }

    //hands
    switch(%uni_lHand)
    {
        case 0:
            %player.unHideNode(lHand);
            %player.setNodeColor(lHand, %zombie_skinColor);
        case 1:
            %player.unHideNode(lHook);
            %player.setNodeColor(lHook, %zombie_skinColor);
    }
    switch(%uni_rHand)
    {
        case 0:
            %player.unHideNode(rHand);
            %player.setNodeColor(rHand, %zombie_skinColor);
        case 1:
            %player.unHideNode(rHook);
            %player.setNodeColor(rHook, %zombie_skinColor);
    }

    //legs and pants/hips
    switch(%uni_hip)
    {
        case 0:
            %player.unHideNode(pants);
            %player.setNodeColor(pants, %uni_hipColor);
            switch(%uni_lLeg)
            {
                case 0:
                    %player.unHideNode(lShoe);
                    %player.setNodeColor(lShoe, %uni_lLegColor);
                case 1:
                    %player.unHideNode(lPeg);
                    %player.setNodeColor(lPeg, %uni_lLegColor);
            }
            switch(%uni_rLeg)
            {
                case 0:
                    %player.unHideNode(rShoe);
                    %player.setNodeColor(rShoe, %uni_rLegColor);
                case 1:
                    %player.unHideNode(rPeg);
                    %player.setNodeColor(rPeg, %uni_rLegColor);
            }
        case 1:
            %player.unHideNode(skirtHip);
            %player.setNodeColor(skirtHip, %uni_hipColor);
            %player.unHideNode(skirtTrimLeft);
            %player.setNodeColor(skirtTrimLeft, %uni_lLegColor);
            %player.unHideNode(skirtTrimRight);
            %player.setNodeColor(skirtTrimRight, %uni_rLegColor);
    }

    //hat
    switch(%uni_hat)
    {
        case 1:
            %player.unHideNode(helmet);
            %player.setNodeColor(helmet, %uni_hatColor);
        case 2:
            %player.unHideNode(pointyHelmet);
            %player.setNodeColor(pointyHelmet, %uni_hatColor);
        case 3:
            %player.unHideNode(flareHelmet);
            %player.setNodeColor(flareHelmet, %uni_hatColor);
        case 4:
            %player.unHideNode(scoutHat);
            %player.setNodeColor(scoutHat, %uni_hatColor);
        case 5:
            %player.unHideNode(bicorn);
            %player.setNodeColor(bicorn, %uni_hatColor);
        case 6:
            %player.unHideNode(copHat);
            %player.setNodeColor(copHat, %uni_hatColor);
        case 7:
            %player.unHideNode(knitHat);
            %player.setNodeColor(knitHat, %uni_hatColor);
    }

    //pack
    switch(%uni_pack)
    {
        case 1:
            %player.unHideNode(armor);
            %player.setNodeColor(armor, %uni_packColor);
        case 2:
            %player.unHideNode(bucket);
            %player.setNodeColor(bucket, %uni_packColor);
        case 3:
            %player.unHideNode(cape);
            %player.setNodeColor(cape, %uni_packColor);
        case 4:
            %player.unHideNode(pack);
            %player.setNodeColor(pack, %uni_packColor);
        case 5:
            %player.unHideNode(quiver);
            %player.setNodeColor(quiver, %uni_packColor);
        case 6:
            %player.unHideNode(tank);
            %player.setNodeColor(tank, %uni_packColor);
    }
    %player.setHeadUp(%uni_pack > 0);

    //secondPack
    switch(%uni_secondPack)
    {
        case 1:
            %player.unHideNode(epaulets);
            %player.setNodeColor(epaulets, %uni_secondPackColor);
        case 2:
            %player.unHideNode(epauletsRankA);
            %player.setNodeColor(epauletsRankA, %uni_secondPackColor);
        case 3:
            %player.unHideNode(epauletsRankB);
            %player.setNodeColor(epauletsRankB, %uni_secondPackColor);
        case 4:
            %player.unHideNode(epauletsRankC);
            %player.setNodeColor(epauletsRankC, %uni_secondPackColor);
        case 5:
            %player.unHideNode(epauletsRankD);
            %player.setNodeColor(epauletsRankD, %uni_secondPackColor);
        case 6:
            %player.unHideNode(shoulderPads);
            %player.setNodeColor(shoulderPads, %uni_secondPackColor);
    }

    //accent
    switch(%uni_hat)
    {
        case 1:
            switch(%uni_accent)
            {
                case 1:
                    //Hide their visor if they have one to show the zombie's face.
                    %player.hideNode(visor);
                    %player.setNodeColor(visor, %uni_accentColor);
            }
        default:
            switch(%uni_accent)
            {
                case 1:
                    %player.unHideNode(plume);
                    %player.setNodeColor(plume, %uni_accentColor);
                case 2:
                    %player.unHideNode(triPlume);
                    %player.setNodeColor(triPlume, %uni_accentColor);
                case 3:
                    %player.unHideNode(septPlume);
                    %player.setNodeColor(septPlume, %uni_accentColor);
            }
    }

    //decals
    %player.setDecalName(%zombie_decalName);
    %player.setFaceName(%zombie_faceName);
    
    %this.applyingUniform = false;
}

//
// Main package.
//

package Server_SCPSL_OFN_Zombify
{
    function Armor::Damage(%data, %obj, %sourceObject, %position, %damage, %damageType)
    {
        if (%obj.getState() $= "Dead")
	    {
		    return;
	    }
        %scale = getWord (%obj.getScale(), 2);
	    %damage = %damage / %scale;
        if(%obj.getDamageLevel()+%damage >= %obj.getDatablock().maxDamage) //Adapted from Swollow's Downed mod. Check if the damage should be fatal.
        {
            %minigame = getMinigameFromObject(%obj);
            if(isSlayerMinigame(%minigame) && %minigame.Teams.getCount() > 1) //Only proceed if the player is in a Slayer minigame and there's an enemy team to be infected to.
            {
                %victimClient = %obj.client;
                %attackerClient = %sourceObject.client;

                if(%obj.getClassName() $= "AIPlayer")
                {
                    %target_team = %obj.getDatablock().hType;
                }
                else
                {
                    %target_team = %victimClient.getTeam();
                }
                %attacker_team = %attackerClient.getTeam();
                %OFN_Team = %minigame.Teams.getTeamFromName($SCPSL::OFN_Team);

                if(%attacker_team $= %OFN_Team && %target_team !$= %OFN_Team) //Check if the attacker is on SCP-049's team and aren't teamkilling.
                {
                    if(!$SCPSL::ZombiesInfect) //Zombie infecting is disabled...
                    {
                        if(!%attackerClient.isOFNZombie) //...But if it's 049 and not a zombie, all clear.
                        {
                            if(getRandom(1, 4) == 1) //Possibly play a neat little sound.
                            {
                                SCPSL_speak(%sourceObject.sourceObject, SCPSL_getRandomSound("OFN_Kidnap", 2), 5000, 0);
                            }
                            %victimClient.OFN_Infect();
                            %attackerClient.incScore(%minigame.points_killPlayer);
                            %attackerClient.addKills(1);
                            %minigame.victoryCheck_Lives(); //This goes in tandem with the "Slayer_TeamSO::getLiving" package found below.
                            return;
                        }
                    }
                    else //Zombie infecting is enabled, nothing to worry about.
                    {
                        if(getRandom(1, 4) == 1)
                        {
                            SCPSL_speak(%sourceObject.sourceObject, SCPSL_getRandomSound("OFN_Kidnap", 2), 500, 0);
                        }
                        %victimClient.OFN_Infect();
                        %attackerClient.incScore(%minigame.points_killPlayer);
                        %attackerClient.addKills(1);
                        %minigame.victoryCheck_Lives();
                        return;
                    }
                }
            }
        }
        parent::Damage(%data, %obj, %sourceObject, %position, %damage, %damageType);
    }
    //Fixes bug where the game doesn't end when all human players are zombies by adding the additional requirement that players also have more than 0 lives.
    function Slayer_TeamSO::getLiving(%this)
    {
        %living = 0;
        for(%i = 0; %i < %this.numMembers; %i ++)
        {
            if(!%this.member[%i].dead() && %this.member[%i].getLives() > 0) //Added no-lives check.
                %living ++;
        }
        return %living;
    }
    //Makes zombies raise their arms after a tumble.
    function Armor::onUnMount (%this, %obj, %vehicle, %node)
    {
        %obj.lastMountTime = getSimTime ();
        if (%node == 0)
        {
            if (isObject (%vehicle))
            {
                %vehicle.onDriverLeave (%obj);
            }
        }
        %obj.setLookLimits (1, 0);
        if(%obj.client.isOFNZombie)
        {
            %obj.playthread(0,"ArmReadyBoth");
        }
        else
        {
            %obj.playThread (0, root);
        }
    }
    //Patch to disable team-join messages if a zombie is rejoining their original team at the end of the round.
    function Slayer_TeamSO::addMember(%this, %client, %reason, %doNotRespawn, %noEquip)
    {
        %mini = getMinigameFromObject(%client);
        if(%mini != %this.minigame || %client.slyrTeam == %this)
            return false;

        if(isObject(%client.slyrTeam))
            %client.slyrTeam.removeMember(%client, 0, %noEquip);

        %class = %client.getClassName();
        if(%this.numMembers[%class] $= "")
            %this.numMembers[%class] = 0;

        %client.slyrTeam = %this;
        %client.slyrTeamJoinTime = getSimTime();

        %this.member[%this.numMembers] = %client;
        %this.numMembers ++;
        %this.member[%class, %this.numMembers[%class]] = %client;
        %this.numMembers[%class] ++;

        //ARE THEY HUMAN OR BOT?
        if(%class $= "GameConnection")
        {
            //If they aren't a zombie joining their original team before the end of the round, go ahead with the messages.
            if( !%client.isOFNZombie || (%client.isOFNZombie && %client.old_team !$= %this) || (%client.isOFNZombie && %client.old_team $= %this && !%mini.isResetting()) )
            {
                //HUMAN - ANNOUNCEMENT
                %msgA = '\c5You have joined %1 %2';
                %msgB = '\c3%1 \c5has joined %2 %3';
                %clName = %client.getPlayerName();
                %teamName = %this.getColoredName();
                %reason = (%reason $= "" ? "" : "\c5(\c3" @ %reason @ "\c5)");
                messageClient(%client, '', %msgA, %teamName, %reason);
                if(%mini.teams_notifyMemberChanges)
                    %mini.messageAllExcept(%client, '', %msgB, %clName, %teamName, %reason);

                clearBottomPrint(%client);
                clearCenterPrint(%client);
            }
        }

        //SPAWN
        if((isObject(%client.player) || %mini.isResetting() || !%client.hasSpawnedOnce) && !%doNotRespawn)
            %client.spawnPlayer();

        %this.onAddMember(%client);

        return true;
    }
    //The gamemode callbacks didn't seem to work. Oh well, I can just do it the crappy way.
    //Removes zombies from their status and moves them back to their original team to prevent shuffling issues.
    function Slayer_MiniGameSO::endRound(%this, %winner, %resetTime)
    {
        if(%winner)
        {
            %team = %this.Teams.getTeamFromName($SCPSL::OFN_Team);
            for(%i = 0; %i < %team.numMembers; %i++)
            {
                %client = %team.member[%i];
                if(%client.isOFNZombie)
                {
                    %client.isOFNZombie = 0;
                    if(%client.old_team)
                    {
                        %client.old_team.addMember(%client, "", 1, 1); 
                    }
                }
            }
        }
        parent::endRound(%this, %winner, %resetTime);
    }
    //These two "GameConnection" packages fix the unlikely bug of someone having their avatar updated and the zombie appearance lost.
    function GameConnection::applyBodyParts(%client)
    {
        if(!%client.isOFNZombie)
        {
            parent::applyBodyParts(%client);
        }
    }
    function GameConnection::applyBodyColors(%client)
    {
        if(!%client.isOFNZombie)
        {
            parent::applyBodyColors(%client);
        }
    }
};
activatepackage(Server_SCPSL_OFN_Zombify);