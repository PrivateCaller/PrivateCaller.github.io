//
// Supporting playertype.
//

datablock PlayerData(OZSStunnedPlayer : PlayerStandardArmor)
{
	runForce = 0;
	maxForwardSpeed = 0;
	maxBackwardSpeed = 0;
	maxSideSpeed = 0;
	maxForwardCrouchSpeed = 0;
	maxBackwardCrouchSpeed = 0;
	maxSideCrouchSpeed = 0;

	jumpForce = 0;
	jumpEnergyDrain = 0;
	minJumpEnergy = 0;
	canJet = 0;
	jetEnergyDrain = 0;
	minJetEnergy = 0;

	runSurfaceAngle  = 0;
	jumpSurfaceAngle = 0;

	uiName = "";
};

//
// Supporting function.
//

function OZS_pickRandomNamedBrick(%name, %minigame_owner)
{
    //Adapted from Jes00's "pickRandNamedBrick" event.
	%name = strReplace(%name, " ", "_");
	%group = getBrickGroupFromObject(%minigame_owner);

	for(%i = 0; %i < %group.NTNameCount; %i++)
	{
		if(%group.NTName[%i] $= ("_" @ %name))
		{
			%nameFound = true;
			break;
		}
	}
	if(!%nameFound)
	{
		return;
	}

	%rand = getRandom(0, %group.NTObjectCount_[%name] - 1);
	%namedBrick = %group.NTObject_[%name, %rand];

	if(isObject(%namedBrick))
	{
		return %namedBrick;
	}
    else
    {
        return "";
    }
}

//
// Main package.
//

package Server_SCPSL_OZS_Teleport
{
    function Armor::Damage(%data, %obj, %sourceObject, %position, %damage, %damageType)
    {
        if (%obj.getState () $= "Dead")
	    {
		    return;
	    }
        %scale = getWord (%obj.getScale (), 2);
	    %damage = %damage / %scale;
        if(%obj.getDamageLevel()+%damage >= %obj.getDatablock().maxDamage) //Only send them to the pocket dimension if they'd otherwise die.
        {
            %minigame = getMinigameFromObject(%obj);
            if(isSlayerMinigame(%minigame) && %minigame.Teams.getCount() > 1)
            {
                %target_team = %obj.client.getTeam();
                %attacker_team = %sourceObject.client.getTeam();
                %OZS_Team = %minigame.Teams.getTeamFromName($SCPSL::OZS_Team);
                if(%attacker_team $= %OZS_Team && %target_team !$= %OZS_Team) //Check if the attacker is on SCP-106's team and aren't teamkilling.
                {
                    %lair_spawnpoint = OZS_pickRandomNamedBrick($SCPSL::OZS_LairVar, findClientByBL_ID(%minigame.creatorBLID));
                    if(%lair_spawnpoint)
                    {
                        %kidnapSound = SCPSL_getRandomSound("OZS_Kidnap", 3);
                        %obj.spawnExplosion(ozsTarProjectile, 1.0);

                        ServerPlay3D(%kidnapSound, %obj.getPosition());
                        %obj.client.playSound(%kidnapSound);
                        SCPSL_speak(%sourceObject.sourceObject, OZS_Laugh, 500, 0);

                        %obj.setDamageLevel(0);
                        %obj.setWhiteout(4000);

                        %obj.setVelocity("0 0 0");
                        %obj.position = %lair_spawnpoint.position;

                        %obj.schedule(3500, "ChangeDataBlock", %obj.getDataBlock()); //Change them back to their original playertype after being froze for a few seconds.
                        %obj.ChangeDataBlock(OZSStunnedPlayer);
                        return;
                    }
                }
            }
        }
        parent::Damage(%data, %obj, %sourceObject, %position, %damage, %damageType);
    }
};
activatepackage(Server_SCPSL_OZS_Teleport);