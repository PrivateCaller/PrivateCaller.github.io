datablock AudioProfile(OFN_Breath)
{
	fileName = "./sounds/OFN_Breath.wav";
	description = AudioCloseLooping3d;
	preload = 0;
};
datablock AudioProfile(OFN_Kidnap1)
{
	filename = "./sounds/OFN_Kidnap1.wav";
    description = AudioClose3d;
    preload = 0;
};
datablock AudioProfile(OFN_Kidnap2 : OFN_Kidnap1)
{
	filename = "./sounds/OFN_Kidnap2.wav";
};
datablock AudioProfile(OFN_Search1 : OFN_Kidnap1)
{
	filename = "./sounds/OFN_Search1.wav";
};
datablock AudioProfile(OFN_Search2 : OFN_Kidnap1)
{
	filename = "./sounds/OFN_Search2.wav";
};
datablock AudioProfile(OFN_Search3 : OFN_Kidnap1)
{
	filename = "./sounds/OFN_Search3.wav";
};
datablock AudioProfile(OFN_Search4 : OFN_Kidnap1)
{
	filename = "./sounds/OFN_Search4.wav";
};
datablock AudioProfile(OFN_Search5 : OFN_Kidnap1)
{
	filename = "./sounds/OFN_Search5.wav";
};
datablock AudioProfile(OFN_Search6 : OFN_Kidnap1)
{
	filename = "./sounds/OFN_Search6.wav";
};
datablock AudioProfile(OFN_Search7 : OFN_Kidnap1)
{
	filename = "./sounds/OFN_Search7.wav";
};
datablock AudioProfile(OFN_Spotted1 : OFN_Kidnap1)
{
	filename = "./sounds/OFN_Spotted1.wav";
};
datablock AudioProfile(OFN_Spotted2 : OFN_Kidnap1)
{
	filename = "./sounds/OFN_Spotted2.wav";
};
datablock AudioProfile(OFN_Spotted3 : OFN_Kidnap1)
{
	filename = "./sounds/OFN_Spotted3.wav";
};
datablock AudioProfile(OFN_Spotted4 : OFN_Kidnap1)
{
	filename = "./sounds/OFN_Spotted4.wav";
};
datablock AudioProfile(OFN_Spotted5 : OFN_Kidnap1)
{
	filename = "./sounds/OFN_Spotted5.wav";
};
datablock AudioProfile(OFN_Spotted6 : OFN_Kidnap1)
{
	filename = "./sounds/OFN_Spotted6.wav";
};
datablock AudioProfile(OFN_Spotted7 : OFN_Kidnap1)
{
	filename = "./sounds/OFN_Spotted7.wav";
};